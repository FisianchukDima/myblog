from distutils.core import setup

setup(
    name='PyMysqlDB',
    version='0.0.2',
    author='jun',
    author_email='jun.mr@qq.com',
    url='http://docs.51pub.cn/python/MysqlDB',
    packages=['PyTools'],
    description='manage mysql tool',
    license='MIT',
    install_requires=['pymysql'],
)
